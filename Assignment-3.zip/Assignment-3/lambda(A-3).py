merge_lists = lambda keys, values: dict(zip(keys, values))
keys = ["name", "age", "city"]
values = ["Aaditya", 19, "Jaipur"]

result = merge_lists(keys, values)
print(result)  
