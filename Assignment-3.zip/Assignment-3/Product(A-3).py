class Product:
    # Class variable for discount rate (default 10%)
    discount_rate = 0.10

    def __init__(self, name, price):
        self.name = name
        self.price = price

    def discounted_price(self):
        """Calculates the price after applying the discount."""
        return self.price * (1 - Product.discount_rate)

# Example usage
product1 = Product("Laptop", 1000)
print(f"Original Price: ${product1.price}")
print(f"Discounted Price: ${product1.discounted_price()}")
