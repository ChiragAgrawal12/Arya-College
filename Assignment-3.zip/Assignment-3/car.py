import math

class Vehicle:
    def __init__(self, brand, model, price_per_day):
        self.brand = brand
        self.model = model
        self.price_per_day = price_per_day

    def vehicle_info(self):
        return f"Brand: {self.brand}, Model: {self.model}, Price per day: ${self.price_per_day}"

class Car(Vehicle):
    def __init__(self, brand, model, price_per_day, seating_capacity):
        super().__init__(brand, model, price_per_day)
        self.seating_capacity = seating_capacity

    def car_info(self):
        return f"{self.vehicle_info()}, Seating Capacity: {self.seating_capacity}"

class Bike(Vehicle):
    def __init__(self, brand, model, price_per_day, type_of_bike):
        super().__init__(brand, model, price_per_day)
        self.type_of_bike = type_of_bike

    def bike_info(self):
        return f"{self.vehicle_info()}, Type: {self.type_of_bike}"

# Example usage
car = Car("Toyota", "Corolla", 50, 5)
bike = Bike("Yamaha", "MT-07", 30, "Sport")

print(car.car_info())
print(bike.bike_info())
